<?php
include_once ('Persona.php');
$persona = new Persona('Fernando', 'Gaitan', 26);

echo $persona -> saludar();

unset($persona);